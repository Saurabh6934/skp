from django.shortcuts import render


def first_show(request):
	ss='This is saurabh project'
	my_dict={'ss':ss}

	return render(request=request, template_name='html/ii/login.html',context=my_dict)


def second_show(request):
	return render(request=request, template_name='html/ii/descrip.html')


def third_show(request):
	return render(request=request, template_name='html/ii/personal.html')


def fourth_show(request):
	return render(request=request, template_name='html/ii/professional.html')

def fifth_show(request):
	return render(request=request, template_name='html/ii/aadhar.html')

def sixth_show(request):
	return render(request=request, template_name='html/ii/btech.html')

def seventh_show(request):
	return render(request=request, template_name='html/ii/btechinfoo.html')

def eighth_show(request):
	return render(request=request, template_name='html/ii/training.html')






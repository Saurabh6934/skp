from django.apps import AppConfig


class IiConfig(AppConfig):
    name = 'ii'
